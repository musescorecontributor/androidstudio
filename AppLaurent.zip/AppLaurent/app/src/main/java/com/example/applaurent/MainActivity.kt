package com.example.applaurent

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val buttonEnvoyer = findViewById<Button>(R.id.Envoyer)
        val Textnom=findViewById<EditText>(R.id.Nom)
        val Textprenom=findViewById<EditText>(R.id.Prenom)
        val Texttaille=findViewById<EditText>(R.id.Taille)
        val Textactivite=findViewById<EditText>(R.id.Activite_sportif)


        buttonEnvoyer.setOnClickListener {

            val intent = Intent(this, MainActivity2::class.java)
            val nom=Textnom.text.toString()
            val prenom=Textprenom.text.toString()
            val taille=Texttaille.text.toString()
            val activite_sportif=Texttaille.text.toString()
            intent.putExtra("Le nom", nom)
            intent.putExtra("Le Prenom",prenom )
            intent.putExtra("La Taille",taille )
            intent.putExtra("activite", activite_sportif)

            startActivity(intent)

        }
    }
}