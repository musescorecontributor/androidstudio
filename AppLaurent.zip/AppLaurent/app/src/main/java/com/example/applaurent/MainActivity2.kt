package com.example.applaurent

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val prenom = intent.getStringExtra("Le Prenom")
        val nom = intent.getStringExtra("Le Nom")
        val taille = intent.getStringExtra("La Taille")
        val activitesportif = intent.getStringExtra("activite")


        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        var TextNom = findViewById<TextView>(R.id.prenom2)


        TextNom.text="Bonjour "+nom +prenom

    }
}